// --- START OF FILE src/features/editor/engine/managers/InteractionManager.ts ---
import * as THREE from "three";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";

import type { A42Engine } from "../A42Engine";

import { useEditorStore } from "@/stores/editor/useEditorStore";
import { useSelectionStore } from "@/stores/selection/useSelectionStore";
import { useCatalogStore } from "@/stores/catalog/useCatalogStore";
import { useSceneStore } from "@/stores/scene/useSceneStore";

export class InteractionManager {
  private engine: A42Engine;
  public transformControl: TransformControls | null = null;

  private raycaster: THREE.Raycaster;
  private pointer: THREE.Vector2;
  private interactionPlane: THREE.Mesh;

  public isDraggingGizmo = false;
  private dragStartPosition = new THREE.Vector3();

  constructor(engine: A42Engine) {
    this.engine = engine;
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();

    // Plano "suelo" para colocar/dibujar cosas
    this.interactionPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(1000, 1000),
      new THREE.MeshBasicMaterial({ visible: false })
    );
    this.interactionPlane.rotation.x = -Math.PI / 2;
    this.interactionPlane.layers.set(0);
    this.engine.scene.add(this.interactionPlane);

    this.initTransformControls();
  }

  // --------------------------------------------------
  // INIT TRANSFORM CONTROLS (GIZMO)
  // --------------------------------------------------
  private initTransformControls() {
    try {
      this.transformControl = new TransformControls(
        this.engine.activeCamera as THREE.Camera,
        this.engine.renderer.domElement
      );

      this.transformControl.rotationSnap = Math.PI / 12;

      // Gizmo en layer 1 (opcional pero organizado)
      this.transformControl.traverse((obj) => {
        obj.layers.set(1);
      });

      this.engine.scene.add(this.transformControl);

      // --- Evento cuando empieza/termina drag ---
      this.transformControl.addEventListener(
        "dragging-changed",
        (event: any) => {
          const editor = useEditorStore.getState();

          this.isDraggingGizmo = event.value;
          this.engine.sceneManager.controls.enabled = !event.value;

          const obj = this.transformControl?.object;
          if (!obj) return;

          if (event.value) {
            // Empezar drag → snapshot para UNDO
            this.dragStartPosition.copy(obj.position);
            editor.saveSnapshot();
          } else {
            // Terminar drag
            if (this.engine.isObjectColliding(obj)) {
              // Rebote si choca zona de seguridad
              this.animateRevert(obj, this.dragStartPosition);
            } else {
              if (obj.userData.isFloorMarker) {
                this.engine.toolsManager.updateFloorFromMarkers(obj);
              } else if (obj.userData.isItem) {
                this.engine.objectManager.adjustObjectToGround(obj);
                this.syncTransformToStore(obj);
              }
            }
          }
        }
      );

      // Ajustar al suelo mientras se mueve (para items)
      this.transformControl.addEventListener("objectChange", () => {
        const obj = this.transformControl?.object;
        if (obj && obj.userData.isItem) {
          this.engine.objectManager.adjustObjectToGround(obj);
        }
      });

      this.transformControl.detach();
      this.transformControl.visible = false;
    } catch (e) {
      console.error("ERROR: TransformControls", e);
      this.transformControl = null;
    }
  }

  // --------------------------------------------------
  // REBOTE EN CASO DE COLISIÓN
  // --------------------------------------------------
  private animateRevert(obj: THREE.Object3D, targetPos: THREE.Vector3) {
    const startPos = obj.position.clone();
    let t = 0;

    const animate = () => {
      t += 0.1;
      if (t >= 1) {
        obj.position.copy(targetPos);
        this.engine.checkSafetyCollisions();
        return;
      }
      obj.position.lerpVectors(startPos, targetPos, t);
      this.engine.checkSafetyCollisions();
      requestAnimationFrame(animate);
    };

    animate();
  }

  // --------------------------------------------------
  // ACTUALIZAR CÁMARA ACTIVA PARA EL GIZMO
  // --------------------------------------------------
  public updateCamera(camera: THREE.Camera) {
    if (this.transformControl) {
      this.transformControl.camera = camera;
    }
  }

  // --------------------------------------------------
  // MOUSE DOWN PRINCIPAL
  // --------------------------------------------------
  public onMouseDown = (event: MouseEvent) => {
    // Si estamos arrastrando el gizmo, no hacemos nada más
    if (this.transformControl && this.isDraggingGizmo) return;

    const rect = this.engine.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointer, this.engine.activeCamera);

    const editor = useEditorStore.getState();
    const catalog = useCatalogStore.getState();
    const selectionStore = useSelectionStore.getState();
    const scene = useSceneStore.getState();

    const mode = editor.mode;

    // ------------------------------------------------
    // 1) CLICK EN GIZMO → dejar que TransformControls actúe
    // ------------------------------------------------
    if (this.transformControl) {
      const gizmoObjects: THREE.Object3D[] = [];
      this.transformControl.traverse((child) => gizmoObjects.push(child));

      const gizmoHits = this.raycaster.intersectObjects(gizmoObjects, true);
      if (gizmoHits.length > 0) {
        // Click sobre el gizmo → NO tocar selección ni modos
        return;
      }
    }

    // ----------------------------
    // DRAW FLOOR
    // ----------------------------
    if (mode === "drawing_floor") {
      const intersects = this.raycaster.intersectObject(this.interactionPlane);
      if (intersects.length > 0) {
        if (event.button === 0) {
          this.engine.toolsManager.addDraftPoint(intersects[0].point);
        } else if (event.button === 2) {
          if (this.engine.toolsManager.floorPoints.length >= 3) {
            this.engine.toolsManager.createSolidFloor();
          }
        }
      }
      return;
    }

    // ----------------------------
    // DRAW FENCE
    // ----------------------------
    if (mode === "drawing_fence") {
      const intersects = this.raycaster.intersectObject(this.interactionPlane);
      if (intersects.length > 0) {
        if (event.button === 0) {
          this.engine.toolsManager.addFenceDraftPoint(intersects[0].point);
        } else if (event.button === 2) {
          this.engine.toolsManager.createSolidFence();
        }
      }
      return;
    }

    // ----------------------------
    // MEASURING
    // ----------------------------
    if (mode === "measuring") {
      const intersects = this.raycaster.intersectObjects(
        this.engine.scene.children,
        true
      );
      const hit = intersects.find(
        (i) =>
          i.object.visible &&
          (i.object.userData.isItem || i.object === this.interactionPlane)
      );

      if (hit) {
        this.engine.toolsManager.handleMeasurementClick(hit.point);
      } else {
        const planeHit = this.raycaster.intersectObject(this.interactionPlane);
        if (planeHit.length > 0) {
          this.engine.toolsManager.handleMeasurementClick(planeHit[0].point);
        }
      }
      return;
    }

    // ----------------------------
    // PLACE ITEM
    // ----------------------------
    if (mode === "placing_item" && catalog.selectedProduct) {
      if (event.button !== 0) return;

      const intersects = this.raycaster.intersectObject(this.interactionPlane);
      if (intersects.length > 0) {
        this.engine.objectManager.placeObject(
          intersects[0].point.x,
          intersects[0].point.z,
          catalog.selectedProduct,
          (uuid) => {
            // Seleccionamos el nuevo objeto y entramos en edición
            selectionStore.selectItem(uuid);
            editor.setMode("editing");
          }
        );
      }
      return;
    }

    // ----------------------------
    // IDLE / EDITING
    // ----------------------------
    if (mode === "idle" || mode === "editing") {
      if (event.button !== 0) return;

      // --- Edición de vértices de suelo ---
      if (this.engine.toolsManager.floorEditMarkers.length > 0) {
        const markerIntersects = this.raycaster.intersectObjects(
          this.engine.toolsManager.floorEditMarkers
        );

        if (markerIntersects.length > 0) {
          const hit = markerIntersects[0].object;
          const index = hit.userData.pointIndex;

          if (event.shiftKey || event.ctrlKey) {
            this.engine.toolsManager.selectVertex(index, true);
            if (this.transformControl) this.transformControl.detach();
            return;
          }

          this.engine.toolsManager.selectVertex(index, false);
          if (this.transformControl) {
            this.transformControl.attach(hit);
            this.transformControl.setMode("translate");
            this.transformControl.visible = true;
          }
          return;
        }
      }

      // --- Selección de objetos ---
      const intersects = this.raycaster.intersectObjects(
        this.engine.scene.children,
        true
      );

      let target: THREE.Object3D | null = null;

      for (const hit of intersects) {
        let obj: THREE.Object3D | null = hit.object;
        let isGizmo = false;

        while (obj) {
          if (this.transformControl && obj === this.transformControl) {
            isGizmo = true;
            break;
          }
          if (obj.userData?.isItem) break;
          obj = obj.parent as THREE.Object3D | null;
        }

        if (isGizmo) {
          // Click en el gizmo → no cambiar selección
          return;
        }

        if (obj && obj.userData?.isItem) {
          target = obj;
          break;
        }
      }

      if (target && target.userData?.isItem) {
        this.selectObject(target);

        // Buscar el SceneItem correspondiente
        const floor = scene.items.find(
          (item) => item.uuid === target!.uuid && item.type === "floor"
        );

        if (floor?.points) {
          this.engine.toolsManager.showFloorEditMarkers(
            target.uuid,
            floor.points
          );
        } else {
          this.engine.toolsManager.clearFloorEditMarkers();
        }
      } else {
        // Click en vacío → deseleccionar (si no estamos en un marker)
        if (
          this.transformControl?.object &&
          !this.engine.toolsManager.floorEditMarkers.includes(
            this.transformControl.object as THREE.Mesh
          )
        ) {
          this.selectObject(null);
          this.engine.toolsManager.clearFloorEditMarkers();
        }
      }
    }
  };

  // --------------------------------------------------
  // SELECCIÓN DE OBJETO + MODO
  // --------------------------------------------------
  public selectObject(object: THREE.Object3D | null) {
    const selection = useSelectionStore.getState();
    const editor = useEditorStore.getState();

    if (!this.transformControl) {
      selection.selectItem(null);
      editor.setMode("idle");
      return;
    }

    // Si clicamos de nuevo en el mismo objeto ya enganchado
    if (
      object &&
      this.transformControl.object?.uuid === object.uuid &&
      selection.selectedItemId !== object.uuid
    ) {
      selection.selectItem(object.uuid);
      editor.setMode("editing");
      return;
    }

    // Quitamos cualquier selección previa
    if (this.transformControl.object) {
      this.transformControl.detach();
      this.transformControl.visible = false;
      this.engine.sceneManager.controls.enabled = true;
    }

    // Si no hay objeto → deseleccionar
    if (!object) {
      selection.selectItem(null);
      editor.setMode("idle");
      return;
    }

    // Nueva selección
    this.transformControl.attach(object);
    selection.selectItem(object.uuid);
    editor.setMode("editing");
    this.transformControl.visible = true;
  }

  // --------------------------------------------------
  // SINCRONIZAR POS / ROT / SCALE CON STORE
  // --------------------------------------------------
  private syncTransformToStore(obj: THREE.Object3D) {
    const scene = useSceneStore.getState();
    if (obj.userData.isItem) {
      scene.updateItem(obj.uuid, {
        position: [obj.position.x, obj.position.y, obj.position.z],
        rotation: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
        scale: [obj.scale.x, obj.scale.y, obj.scale.z],
      });
    }
  }

  // --------------------------------------------------
  // CAMBIAR MODO DEL GIZMO
  // --------------------------------------------------
  public setGizmoMode(mode: "translate" | "rotate" | "scale") {
    if (this.transformControl) this.transformControl.setMode(mode);
  }
}
// --- END OF FILE src/features/editor/engine/managers/InteractionManager.ts ---
