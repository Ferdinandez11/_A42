import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  
  // 1. TU CONFIGURACIÓN ACTUAL (Vital para Three.js)
  resolve: {
    alias: {
      // Mantener this para evitar varias copias de Three
      three: path.resolve(__dirname, './node_modules/three'),

      '@': path.resolve(__dirname, './src'),
      '@features': path.resolve(__dirname, './src/features'),
      '@stores': path.resolve(__dirname, './src/stores'),
      '@lib': path.resolve(__dirname, './src/lib'),
      '@utils': path.resolve(__dirname, './src/utils'),
      '@components': path.resolve(__dirname, './src/components')
    }
  },

  // 2. CONFIGURACIÓN DE OPTIMIZACIÓN (Para quitar el aviso amarillo)
  build: {
    chunkSizeWarningLimit: 1600, // Aumentamos el límite de aviso a 1.6MB
    rollupOptions: {
      output: {
        manualChunks(id) {
          // Separa las librerías (node_modules) del código de tu app
          // Esto crea un archivo 'vendor.js' que el navegador cachea mejor
          if (id.includes('node_modules')) {
            return 'vendor';
          }
        }
      }
    }
  }
})